create view hr_employee_skill_report
            (id, employee_id, company_id, department_id, skill_id, skill_type_id, level_progress, skill_level) as
SELECT row_number() OVER ()               AS id,
       e.id                               AS employee_id,
       e.company_id,
       e.department_id,
       s.skill_id,
       s.skill_type_id,
       sl.level_progress::numeric / 100.0 AS level_progress,
       sl.name                            AS skill_level
FROM hr_employee e
         LEFT JOIN hr_employee_skill s ON e.id = s.employee_id
         LEFT JOIN hr_skill_level sl ON sl.id = s.skill_level_id;

alter table hr_employee_skill_report
    owner to odoo;

