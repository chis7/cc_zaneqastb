create view hr_employee_public
            (name, active, color, department_id, job_id, job_title, company_id, address_id, work_phone, mobile_phone,
             work_email, work_contact_id, work_location_id, user_id, resource_id, resource_calendar_id, parent_id,
             coach_id, create_date, id, create_uid, write_uid, write_date)
as
SELECT emp.name,
       emp.active,
       emp.color,
       emp.department_id,
       emp.job_id,
       emp.job_title,
       emp.company_id,
       emp.address_id,
       emp.work_phone,
       emp.mobile_phone,
       emp.work_email,
       emp.work_contact_id,
       emp.work_location_id,
       emp.user_id,
       emp.resource_id,
       emp.resource_calendar_id,
       emp.parent_id,
       emp.coach_id,
       emp.create_date,
       emp.id,
       emp.create_uid,
       emp.write_uid,
       emp.write_date
FROM hr_employee emp;

alter table hr_employee_public
    owner to odoo;

